KeyMonitor Combined

Run BUILD_ON_WINDOWS.cmd on a Windows PC with the .NET Framework 4.x C# compiler available. This creates KeyMonitor_Combined.exe in this folder.

The app monitors both general keyboard events and registered shortcuts in one visible log. Monitoring requires confirmation. While active, the Minimize button and standard minimize system commands are disabled. Monitoring still stops if the window is unexpectedly minimized, and does not resume automatically. Windows desktop-wide actions (such as Show Desktop) may still obscure the window; these cannot be fully blocked by an ordinary application.

Important: Windows registered global shortcuts may prevent those shortcuts from reaching other applications. Registration failures are logged. This package has not been compiled or tested on Windows in this environment.

Version 4 layout changes:
- Optional Always on top checkbox, switchable while running.
- Compact 480 x 335 client area with two rows of two buttons.
- Log sized to accommodate a complete millisecond timestamp and
  longer combinations such as "KEY  LShift + Enter".
- Monitoring, shortcuts, consent and minimize protections unchanged.
- Windows compilation and visual testing remain pending.
